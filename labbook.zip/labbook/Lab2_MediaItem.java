package capgemini.labbook;

public abstract class Lab2_MediaItem extends Lab2_Item {
	private int runtime;

	public Lab2_MediaItem(int Identificationnumber, String Title, int Numberofcopies, int runtime) {
		super(Identificationnumber, Title, Numberofcopies);

		this.runtime = runtime;
	}

	public int getRuntime() {
		return runtime;
	}

	public void setRuntime(int runtime) {
		this.runtime = runtime;
	}

	@Override
	public String toString() {
		return "MediaItem [runtime=" + runtime + "]";
	}

	public abstract void Print();

	public abstract void CheckIn();

	public abstract void CheckOut();

	public abstract void AddItem(int n);

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Lab2_MediaItem other = (Lab2_MediaItem) obj;
		if (runtime != other.runtime)
			return false;
		return true;
	}

}
