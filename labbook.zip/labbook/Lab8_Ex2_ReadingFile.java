package capgemini.labbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Lab8_Ex2_ReadingFile {
	public static void main(String[] args) {
		fileInputStream();
	
	}
	public static void fileInputStream() {
		File file = new File("C:\\capgemini\\File\\FileRead.txt");
		FileInputStream fileInput=null;
		try {
			 fileInput = new FileInputStream(file);
			int input = 0;
			int count=1;
			System.out.print(count +" ");
			while ((input = fileInput.read()) != -1) {
				
				System.out.print((char) input);
				if((char)input=='\n'){
					count++;
					System.out.print(count +" ");
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		  finally{
			  try{
				  fileInput.close();
				  } catch(IOException e){
		  e.printStackTrace();
		  }
	}
}

}
