package capgemini.labbook;

public abstract class Lab2_WrittenItem extends Lab2_Item {
	// fields
	private String Authorname;

	public Lab2_WrittenItem(int identificationnumber, String title, int numberofcopies, String authorname) {
		super(identificationnumber, title, numberofcopies);
		this.Authorname = authorname;
	}

	public String getAuthorname() {
		return Authorname;
	}

	public void setAuthorname(String authorname) {
		this.Authorname = authorname;
	}

	public abstract void Print();

	public abstract void CheckIn();

	public abstract void CheckOut();

	public abstract void AddItem(int n);

	@Override
	public String toString() {
		return "WrittenItem [Authorname=" + Authorname + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Lab2_WrittenItem other = (Lab2_WrittenItem) obj;
		if (Authorname == null) {
			if (other.Authorname != null)
				return false;
		} else if (!Authorname.equals(other.Authorname))
			return false;
		return true;
	}

}
