package capgemini.labbook;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class Lab8_Ex3_Count {
	public static void main(String args[]) throws IOException {
		File file = new File("C:\\Capgemini\\File\\ReadME.txt");
		FileInputStream fs = new FileInputStream(file);
		InputStreamReader isr = new InputStreamReader(fs);
		BufferedReader br = new BufferedReader(isr);

		int words = 0;
		int lines=0;
		String str = null;
		int charc = 0;

		try {
			while ((str = br.readLine()) != null) {

				if (!(str.equals(""))) {
					charc += str.length();
					String[] wl = str.split("\\s+");
					words = wl.length;
					lines++;
				}
			}
			System.out.println("No. of chracters = " + charc);
			System.out.println("No. of words = " + words);
			System.out.println("No. of lines = " + lines);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
