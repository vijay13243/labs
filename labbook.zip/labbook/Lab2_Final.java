package capgemini.labbook;

public class Lab2_Final {
	public static void main(String args[]) {
		Lab2_Book b = new Lab2_Book(100, "VIJAY", 20, "Sriram");
		Lab2_Video v = new Lab2_Video(100, "VIJAY", 20, 60, "Sriram", "action", 1998);
		Lab2_Cd c = new Lab2_Cd(100, "VIJAY", 20, 60, "Sriram", "action");
		Lab2_JournalPaper j = new Lab2_JournalPaper(100, "VIJAY", 20, "Sriram", 1997);
		System.out.println("PRINTING BOOK DATA");
		b.Print();
		b.AddItem(10);
		b.CheckIn();
		b.CheckOut();
		System.out.println();
		System.out.println("PRINTING VIDEO DATA");
		v.Print();
		v.CheckIn();
		v.CheckOut();
		v.AddItem(20);
		System.out.println();
		System.out.println("PRINTING JOURNAL DATA");
		j.Print();
		j.AddItem(50);
		j.CheckIn();
		j.CheckOut();
		j.AddItem(100);
		System.out.println();
		System.out.println("PRINTING CD DATA");
		c.AddItem(100);
		c.CheckIn();
		c.CheckOut();
		c.Print();
 
	}

}
